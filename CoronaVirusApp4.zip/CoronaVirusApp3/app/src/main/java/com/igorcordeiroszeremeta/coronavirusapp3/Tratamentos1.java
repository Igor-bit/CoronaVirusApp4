package com.igorcordeiroszeremeta.coronavirusapp3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Tratamentos1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tratamentos1);
    }
}
